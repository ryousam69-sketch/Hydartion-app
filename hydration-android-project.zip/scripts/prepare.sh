#!/usr/bin/env bash
# Builds the Android project around the web app. Run from the project root.
set -euo pipefail

# 1. web files the app needs
rm -rf www && mkdir -p www
cp index.html manifest.webmanifest icon-192.png icon-512.png www/

# 2. generate the Android project
rm -rf android
npx cap add android

APP=android/app/src/main
RES=$APP/res

# 3. permissions: notifications, exact alarms, re-arm reminders after a reboot
sed -i 's|<application|<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />\n    <uses-permission android:name="android.permission.USE_EXACT_ALARM" />\n    <uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM" />\n    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />\n    <application|' $APP/AndroidManifest.xml

# 4. small notification icon (white water drop)
mkdir -p $RES/drawable
cp android-res/ic_stat_water.xml $RES/drawable/ic_stat_water.xml

# 5. launcher icon: use our drop instead of the default one
for d in $RES/mipmap-*; do
  case "$d" in
    *anydpi*) rm -rf "$d" ;;
    *) cp icon-192.png "$d/ic_launcher.png"; cp icon-192.png "$d/ic_launcher_round.png"; rm -f "$d/ic_launcher_foreground.png" ;;
  esac
done

# 6. copy everything into the Android project
npx cap sync android
echo "Android project ready in ./android"
